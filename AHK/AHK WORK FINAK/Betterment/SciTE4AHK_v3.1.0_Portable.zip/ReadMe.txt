SciTE4AutoHotkey v3.1.0 Portable Edition
========================================

Thank you for downloading SciTE4AutoHotkey.
Supported platforms: Windows Vista, 7, 8, 8.1, 10, 11

AutoHotkey v1.1+ (and optionally AutoHotkey v2) is required.

Installation: unpack this archive to your AutoHotkey folder so that you have:

AutoHotkey
|_______ AutoHotkey.exe
|_______ AutoHotkeyA32.exe
|_______ AutoHotkeyU32.exe
|_______ AutoHotkeyU64.exe
|_______ AutoHotkey.chm
|_______ v2
|        |_______ AutoHotkey32.exe
|        |_______ AutoHotkey64.exe
|        |_______ AutoHotkey.chm
|_______ SciTE
         |______ etc...